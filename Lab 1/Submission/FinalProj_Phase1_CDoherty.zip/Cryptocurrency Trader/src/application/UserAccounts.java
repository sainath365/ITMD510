package application;

public class UserAccounts {
	public int ID;
	public String username;
	public String password;
	public String accountType;
}
