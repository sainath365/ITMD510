package application;

public interface Trader {
	public void UserAccounts();
	public void Exchange();
	public void Currency();
	public void Transaction();
	public void Account();
	
}
