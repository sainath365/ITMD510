package application;

public class Exchnge {

	public int userID;
	public int currencyID;
	
	public void currencyHistory() {}
	public void userHistory() {}
	public void performTransaction() {}
	
	private UserAccounts useraccounts;
	private Currency currency;
	
	private Transaction transaction;
}