package application;

public class Account {

	public int accountID;
	public int userID;
	public double accountBalanceUSD;
	public double accountBalanceBTC;
	public double accountBalanceLTC;
	
	private Transaction transaction;
	
}
