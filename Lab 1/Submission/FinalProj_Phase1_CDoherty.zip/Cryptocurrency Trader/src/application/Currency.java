package application;

public class Currency {
	public int ID;
	public String name;
	public double price;
}
