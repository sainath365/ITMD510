package application;

public class Transaction {

	public int transactionID;
	public int currencyID;
	public double currencyPrice;
	
	public void transactionHistory() {}
	public void buyBTC() {}
	public void buyLTC() {}
	public void sellBTC() {}
	public void sellLTC() {}
	
	private Account account;
	
}
