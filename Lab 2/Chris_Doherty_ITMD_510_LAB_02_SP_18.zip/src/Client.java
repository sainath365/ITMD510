/**
 * This program is for Lab 2 of ITMD 511
 * This abstract class allows for three abstract methods the bank needs to process.
 * 
 */

/**
 * @author Chris
 *
 */
public abstract class Client {
	public void readData() {
		
	}
	public void processData(){
		
	}
	public void printData(){
		
	}
}
