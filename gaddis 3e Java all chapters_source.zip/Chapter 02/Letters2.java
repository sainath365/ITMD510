// This program demonstrates the close relationship between
// characters and integers.

public class Letters2
{
   public static void main(String[] args)
   {
      char letter;

      letter = 65;
      System.out.println(letter);
      letter = 66;
      System.out.println(letter);
   }
}
