/**
   This class demonstrates the Hanoi class, which
   displays the steps necessary to solve the Towers
   of Hanoi game.
*/

public class HanoiDemo
{
   static public void main(String[] args)
   {
      Hanoi towersOfHanoi = new Hanoi(3);
   }
}