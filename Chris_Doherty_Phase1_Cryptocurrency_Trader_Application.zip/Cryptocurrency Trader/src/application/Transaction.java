package application;

public class Transaction {

	public int transactionID;
	public double currencyPrice;
	
	public Wallet wallet;
	
}
