package application;

public class Account extends Exchange {
	
	public int ID;
	public String username;
	public String password;	
}
