package application;

public class Wallet {

	public String walletId;
	public String transactionReceiptID;
	public long depositeAmount;
	public long balance;
	
}
