package application;

public class Exchange {

	public int currencyID;
	public String currencyName;
	public long currencyPrice;
	public String currencyCode;
	
	
}