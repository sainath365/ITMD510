package application;

public class AdminAccount extends Account implements AdminOperations {

	public String adminID;
	public String fullName;
	public String role;
	@Override
	public void viewTransactionHistory() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void viewTraderActivity() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void viewTraderBalance() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void approveAccountUpdates() {
		// TODO Auto-generated method stub
		
	}
}
