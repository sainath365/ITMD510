package application;

public interface AdminOperations {

	public void viewTransactionHistory();
	public void viewTraderActivity();
	public void viewTraderBalance();
	public void approveAccountUpdates();
}
